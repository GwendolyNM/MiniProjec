package com.dto;

public class StoreDTO {
	int num;
	String name;
	String type;
	int price;
	int stock;
	
	public StoreDTO() {	}

	public StoreDTO(int num, String name, String type, int price, int stock) {
		this.num = num;
		this.name = name;
		this.type = type;
		this.price = price;
		this.stock = stock;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	@Override
	public String toString() {
		return "StoreDTO [num=" + num + ", name=" + name + ", type=" + type + ", price=" + price + ", stock=" + stock
				+ "]";
	}


	
	
	
}
