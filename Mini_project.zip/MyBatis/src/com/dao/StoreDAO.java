
package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.StoreDTO;

public class StoreDAO {
public List<StoreDTO> findAll(SqlSession session){
List<StoreDTO> list =
session.selectList("com.config.StoreMapper.findAll");
return list;
}



}











