package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.StoreDAO;
import com.dto.StoreDTO;

public class StoreServiceImpl implements StoreService {
	private StoreDAO dao;
	public void setDao(StoreDAO dao) {
		this.dao = dao;
	}

	
	@Override
	public List<StoreDTO> findAll() {
	 List<StoreDTO> list = null;	
	 SqlSession session = null;
      try {
		session = MySqlSessionFactory.getSession();
		list = dao.findAll(session);
      }finally {
		session.close();
      }
	  return list;
	}
}
