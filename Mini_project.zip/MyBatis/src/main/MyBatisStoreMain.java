package main;

import java.util.List;
import java.util.Scanner;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dto.StoreDTO;

public class MyBatisStoreMain {
	
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("제품종류를 골라주세요.");
		
		SqlSession session = MySqlSessionFactory.getSession();
		
		//List<StoreDTO> list = session.selectList("com.config.StoreMapper.findAll");
		//for (StoreDTO e : list) {
			
		//}
		
		List<StoreDTO> list1 = session.selectList("com.config.StoreMapper.findType");
		for (StoreDTO e1 : list1) {
			System.out.println(e1);
		}
		
		
		
}
}