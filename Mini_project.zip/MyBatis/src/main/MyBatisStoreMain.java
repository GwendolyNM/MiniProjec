package main;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dto.StoreDTO;

public class MyBatisStoreMain {

	public static void main(String[] args) {
		SqlSession session = MySqlSessionFactory.getSession();
		List<StoreDTO> list = session.selectList("com.config.StoreMapper.findAll");
		System.out.println(list);
		
		StoreDTO findone  = session.selectOne("com.config.StoreMapper.findBynum", 1);
		System.out.println(findone);
		
		StoreDTO dto = new StoreDTO(12, "바나나우유", "음료", 1500, 100);
		int n = session.insert("com.config.StoreMapper.save");
		session.commit();
		System.out.println(n +" 개가 생성됨 ");
}
}